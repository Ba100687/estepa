

<?php
if (isset($_POST['nombre']) && isset($_POST['telefono']) && isset($_POST['email'])) {
    $subs_name = utf8_decode($_POST['nombre']);
    $subs_telefono = utf8_decode($_POST['telefono']);
    $subs_email = utf8_decode($_POST['email']);

    $conn = mysqli_connect("localhost", "id21220502_tesis_name", "Tesis@2023", "id21220502_tesis_db");

    if (!$conn) {
        die("Error de conexión: " . mysqli_connect_error());
    }

    // Verificar si ya existe un registro con los mismos datos
    $check_query = "SELECT * FROM usuariospendientes WHERE correo = '$subs_email'";
    $check_result = mysqli_query($conn, $check_query);

    if (mysqli_num_rows($check_result) > 0) {
        $message = "Ya existe un registro con estos datos.";
         $redirect = "https://360security.000webhostapp.com/formulario.html";
        
    } else {
        // Insertar el nuevo registro
        $insert_query = "INSERT INTO usuariospendientes (nombre, telefono, correo) VALUES ('$subs_name', '$subs_telefono', '$subs_email')";
        
        if (mysqli_query($conn, $insert_query)) {
               // Enviar el correo electrónico
                    //encargado
                    $to = "sebastianmacana8@gmail.com";
                    $subject = "Solicitud de Atencion Personalizada";   
                    $message = "Se ha registrado un nuevo usuario:\nNombre: $subs_name\nTeléfono: $subs_telefono\nCorreo: $subs_email";
                    
                    //cliente
                    $tocliente = $subs_email;
                    $subjectcliente = "Solicitud de Atencion Personalizada exitosa";
                    $messagecliente = "Hola Sr(@): $subs_name, Se ha registrado su solicitud.";
                    $headers = "From: seguridadllano360@tesis.com";
                    
                    mail($to, $subject, $message, $headers);
                    mail($tocliente, $subjectcliente, $messagecliente, $headers);
                    
             $message = "Registro insertado correctamente, correo enviado.";
             $redirect = "https://360security.000webhostapp.com/home.html";
             
        } else {
            $message = "Error al insertar el registro: " . mysqli_error($conn);
                 $redirect = "https://360security.000webhostapp.com/formulario.html";
        }
    }

    mysqli_close($conn);

// Redirigir después de haber terminado con las operaciones
echo "<script>
    alert('$message');
    window.location.href = '$redirect';
</script>";

} else {
    echo "Ingrese todos los campos.";
}











