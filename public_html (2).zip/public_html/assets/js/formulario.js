
 //sombra al navbar al hacer scroll
 const navbar = document.querySelector('.custom-navbar');

 window.addEventListener('scroll', () => {
   if (window.scrollY > 0) {
     navbar.classList.add('scrolled', 'with-shadow'); // Agregar ambas clases
   } else {
     navbar.classList.remove('scrolled', 'with-shadow'); // Eliminar ambas clases
   }
 });


 // smooth scroll desde boton
document.addEventListener("DOMContentLoaded", function() {
    navbar.classList.add('scrolled', 'with-shadow'); // Agregar ambas clases
  });
 